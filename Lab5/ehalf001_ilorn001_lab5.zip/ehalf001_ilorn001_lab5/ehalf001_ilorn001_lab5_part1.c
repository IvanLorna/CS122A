/*    Name & Email: Emanuel Halfon / ehalf001@ucr.edu
 *    Partner(s) Name & E-mail: Ivan Lorna / ilorn001@ucr.edu 
 *    Lab Section:  021
 *    Assignment: Lab 5 Part 1
 *    Exercise Description: [optional - include for your own benefit]
 *    
 *    I acknowledge all content contained herein, excluding template 
 *     or example code, is my own original work.
 */

//Includes
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdio.h>
#include "SPI.h"
#include "keypad.h"
#include "io.h"
#include "io.c"
#include "bit.h"
#include <util/delay.h>

#define B0 (~PINB & 0x01)
#define B1 ((~PINB >> 1) & 0x01)

//Global Variables
unsigned char count; //Counter
volatile unsigned char TimerFlag = 0; // TimerISR() sets this to 1. C programmer should clear to 0.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks
const unsigned long PERIOD = 50; //Preset Period
unsigned char data = 0x00;
//Functions





void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;
	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	SREG |= 0x80; // 0x80: 1000000
}

void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


typedef struct Task {
	int state; // Task�s current state
	unsigned long period; // Task period
	unsigned long elapsedTime; // Time elapsed since last task tick
	int (*TickFct)(int); // Task tick function
} task;

const unsigned char tasksSize = 1;
task tasks[1];

void TimerISR()
{
	unsigned char i;
	for (i = 0;i < tasksSize;++i)
	{
		if ((tasks[i].elapsedTime >= tasks[i].period))
		{
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += PERIOD;
	}
		
}

ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}


void transmit_data(unsigned char data){
	for(unsigned int i = 0; i < 8; i++){
		PORTC = SetBit(PORTC, 3, 1); //Set SRCLR to high
		PORTC = SetBit(PORTC, 6, 0); //Set SRCLK to low
		PORTC = SetBit(PORTC, 4, GetBit(data,i)); //Set SER to send bit
		PORTC = SetBit(PORTC, 6, 1); //Set SRCLK to high
	}
	PORTC = SetBit(PORTC, 5, 1);
	PORTC = SetBit(PORTC, 3, 0); //Set SRCLR to low
}

//state machines
enum ButtonToggleStates{start, incr, decr, reset};
int ButtonToggle(int state)
{
	switch(state)
	{
		case start:
			if(B0 && B1)
			{
				state = reset;
			}
			else if(B0)
			{
				PORTD = PORTD + 1;	
				state = incr;
			}
			else if(B1)
			{
				state = decr;
			}
			else
			{
				state = start;
			}
			break;
		case incr:
			state = start;
			break;
		case decr:
			state = start;
			break;
		case reset:
			state = start;
			break;
		default:
			state = start; 
	}
	
	switch(state)
	{
		case incr:
			data = (data < 0xFF) ? data + 1 : 0xFF;
			break;
		case decr:
			data = (data > 0x00) ? data - 1 : 0x00;
			break;
		case reset:
			data = 0x00;
			break;
		default:
			data = data;
			break;
	}

	PORTC = SetBit(PORTC, 5, 0); //Set RCLK to low
	transmit_data(data);
	return state;
}



int main(void)
{
	DDRC = 0xFF; PORTC = 0x00;
	DDRD = 0xFF; PORTD = 0x00;
	DDRB = 0x00; PORTB = 0xFF;

	PORTC = SetBit(PORTC, 7, 1); //Set SRCLR to high
	PORTC = SetBit(PORTC, 5, 0); //Set RCLK to low
	unsigned char old_data;
	tasks[0].elapsedTime = 0;
	tasks[0].period = 50;
	tasks[0].state = start;
	tasks[0].TickFct = &ButtonToggle;	

	TimerSet(PERIOD);
	TimerOn();
	while (1)
	{
			
		continue;
		//Test

	}
	
}
