/*    Name & Email: Emanuel Halfon / ehalf001@ucr.edu
 *    Partner(s) Name & E-mail: Ivan Lorna / ilorn001@ucr.edu 
 *    Lab Section:  021
 *    Assignment: Lab 5 Part 3
 *    Exercise Description: [optional - include for your own benefit]
 *    
 *    I acknowledge all content contained herein, excluding template 
 *     or example code, is my own original work.
 */

//Includes
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdio.h>
#include "SPI.h"
#include "keypad.h"
#include "io.h"
#include "io.c"
#include "bit.h"
#include <util/delay.h>

#define B0 (~PINB & 0x01)
#define B1 ((~PINB >> 1) & 0x01)
#define B2 ((~PINB >> 2) & 0x01)
#define B3 ((~PINB >> 3) & 0x01)



//Global Variables
unsigned char count; //Counter
volatile unsigned char TimerFlag = 0; // TimerISR() sets this to 1. C programmer should clear to 0.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks
const unsigned long PERIOD = 50; //Preset Period
unsigned char patterns = 0x00;
unsigned char patterns1 = 0x00;
unsigned char data = 0x00;
unsigned char data2 = 0x00;
//Functions





void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;
	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	SREG |= 0x80; // 0x80: 1000000
}

void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


typedef struct Task {
	int state; // Task�s current state
	unsigned long period; // Task period
	unsigned long elapsedTime; // Time elapsed since last task tick
	int (*TickFct)(int); // Task tick function
	int pattern;
} task;

const unsigned char tasksSize = 4;
task tasks[4];

void TimerISR()
{
	unsigned char i;
	for (i = 0;i < tasksSize;++i)
	{
		if ((tasks[i].elapsedTime >= tasks[i].period))
		{
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += PERIOD;
	}
		
}

ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}


void transmit_data(unsigned char data){
	for(unsigned int i = 0; i < 8; i++){
		PORTC = SetBit(PORTC, 3, 1); //Set SRCLR to high
		PORTC = SetBit(PORTC, 6, 0); //Set SRCLK to low
		PORTC = SetBit(PORTC, 4, GetBit(data,i)); //Set SER to send bit
		PORTC = SetBit(PORTC, 6, 1); //Set SRCLK to high
	}
	PORTC = SetBit(PORTC, 5, 1); // RCLK
	PORTC = SetBit(PORTC, 3, 0); //Set SRCLR to low
}

void transmit_data_2(unsigned char data){
	for(unsigned int i = 0; i < 8; i++){
		PORTC = SetBit(PORTC, 0, 1); //Set SRCLR to high
		PORTC = SetBit(PORTC, 6, 0); //Set SRCLK to low
		PORTC = SetBit(PORTC, 4, GetBit(data,i)); //Set SER to send bit
		PORTC = SetBit(PORTC, 6, 1); //Set SRCLK to high
	}
	PORTC = SetBit(PORTC, 1, 1); // RCLK
	PORTC = SetBit(PORTC, 0, 0); //Set SRCLR to low
}

//state machines
enum ButtonToggleStates{start, incr, decr, reset, toggle};
int ButtonToggle(int state)
{
	switch(state)
	{
		case start:
			if(B0 && B1)
			{
				state = reset;
			}
			else if(B0)
			{	
				state = incr;
			}
			else if(B1)
			{
				state = decr;
			}
			else
			{
				state = start;
			}
			break;
		case incr:
			state = toggle;
			break;
		case decr:
			state = toggle;
			break;
		case reset:
			state = (B0 && B1) ? toggle : reset;
			if(state == start)
			{
				patterns = tasks[0].pattern;
			}
			break;
		case toggle:
			state = (!B0 && !B1) ? start : toggle;
			//state = (B0 && B1) ? reset : state;
			break;
		default:
			state = start; 
	}
	
	switch(state)
	{
		case incr:
			patterns = (patterns < 2) ? patterns + 1 : 0x00;
			break;
		case decr:
			patterns = (patterns > 0x00) ? patterns - 1 : 0x02;
			break;
		case toggle:
			break;
		case reset:
			patterns = 0x03;
			break;
		default:
			data = data;
			break;
	}

	return state;
}

enum ButtonToggleStates2{start_2, incr_2, decr_2, reset_2, toggle_2};
int ButtonToggle2(int state)
{
	switch(state)
	{
		case start_2:
		if(B2 && B3)
		{
			state = reset_2;
		}
		else if(B2)
		{
			state = incr_2;
		}
		else if(B3)
		{
			state = decr_2;
		}
		else
		{
			state = start_2;
		}
		break;
		case incr_2:
		state = toggle_2;
		break;
		case decr_2:
		state = toggle_2;
		break;
		case reset_2:
		state = (B2 && B3) ? toggle_2 : reset_2;
		if(state == start_2)
		{
			patterns = tasks[2].pattern;
		}
		break;
		case toggle_2:
		state = (!B2 && !B3) ? start_2 : toggle_2;
		//state = (B0 && B1) ? reset : state;
		break;
		default:
		state = start_2;
	}
	
	switch(state)
	{
		case incr_2:
		patterns1 = (patterns1 < 2) ? patterns1 + 1 : 0x00;
		break;
		case decr_2:
		patterns1 = (patterns1 > 0x00) ? patterns1 - 1 : 0x02;
		break;
		case toggle_2:
		break;
		case reset_2:
		patterns1 = 0x03;
		break;
		default:
		patterns1 = patterns1;
		break;
	}

	return state;
}


enum PatternOneStates {Start_One, Low, High};
int PatternOne(int state)
{
	switch(state){//transition
		case Start_One:
		state = Low;
		break;
		case Low:
		state = High;
		break;
		case High:
		state = Low;
		break;
		default:
		state = Start_One;
	}
	
	switch(state){//action
		case Low:
		data = 0xF0;
		break;
		case High:
		data = 0x0F;
		break;
		default:
		data = data;
	}
	PORTC = SetBit(PORTC, 5, 0); //Set RCLK to low
	transmit_data(data);
	return state;
}

enum PatternOneStates_2 {Start_One_2, Low_2, High_2};
int PatternOne_2(int state)
{
	switch(state){//transition
		case Start_One_2:
		state = Low_2;
		break;
		case Low_2:
		state = High_2;
		break;
		case High_2:
		state = Low_2;
		break;
		default:
		state = Start_One_2;
	}
	
	switch(state){//action
		case Low_2:
		data2 = 0xF0;
		break;
		case High_2:
		data2 = 0x0F;
		break;
		default:
		data2 = data2;
	}
	PORTC = SetBit(PORTC, 1, 0); //Set RCLK to low
	transmit_data(data2);
	return state;
}


enum PatternTwoStates {Start_Two, A_A, f_f,};
int PatternTwo(int state){
	switch(state){//transition
		case Start_Two:
		state = A_A;
		break;
		case A_A:
		state = f_f;
		break;
		case f_f:
		state = A_A;
		break;
		default:
		state = Start_Two;
	}
	
	switch(state){//action
		case Low:
		data = 0xAA;
		break;
		case High:
		data = 0x55;
		break;
		default:
		data = data;
	}
	PORTC = SetBit(PORTC, 5, 0); //Set RCLK to low
	transmit_data(data);	
	return state;
}

enum PatternTwoStates_2 {Start_Two_2, A_A_2, f_f_2};
int PatternTwo_2(int state){
	switch(state){//transition
		case Start_Two_2:
		state = A_A_2;
		break;
		case A_A_2:
		state = f_f_2;
		break;
		case f_f_2:
		state = A_A_2;
		break;
		default:
		state = Start_Two_2;
	}
	
	switch(state){//action
		case Low_2:
		data2 = 0xAA;
		break;
		case High_2:
		data2 = 0x55;
		break;
		default:
		data2 = data2;
	}
	PORTC = SetBit(PORTC, 1, 0); //Set RCLK to low
	transmit_data(data2);
	return state;
}

enum PatternThreeStates {Start_Three, Shift_Down, Shift_Up};
int PatternThree(int state){
	switch(state){//transition
		case Start_Three:
		data = 0x80;
		state = Shift_Down;
		break;
		case Shift_Down:
		state = (data == 0x01) ? Shift_Up : Shift_Down;
		break;
		case Shift_Up:
		state = (data == 0x80) ? Shift_Down : Shift_Up;
		break;
		default:
		state = Start_Three;
	}
	
	switch(state){//action
		case Shift_Down:
		data = data >> 1;
		break;
		case Shift_Up:
		data = data << 1;
		break;
		default:
		data = data;
	}
	PORTC = SetBit(PORTC, 5, 0); //Set RCLK to low
	transmit_data(data);
	return state;
}

enum PatternThreeStates_2 {Start_Three_2, Shift_Down_2, Shift_Up_2};
int PatternThree_2(int state){
	switch(state){//transition
		case Start_Three_2:
		data = 0x80;
		state = Shift_Down_2;
		break;
		case Shift_Down_2:
		state = (data2 == 0x01) ? Shift_Up_2 : Shift_Down_2;
		break;
		case Shift_Up_2:
		state = (data2 == 0x80) ? Shift_Down_2 : Shift_Up_2;
		break;
		default:
		state = Start_Three_2;
	}
	
	switch(state){//action
		case Shift_Down_2:
		data2 = data2 >> 1;
		break;
		case Shift_Up_2:
		data2 = data2 << 1;
		break;
		default:
		data2 = data2;
	}
	PORTC = SetBit(PORTC, 1, 0); //Set RCLK to low
	transmit_data(data2);
	return state;
}

enum PatternFourStates {Start_Four};
void PatternFour(int state)
{
	PORTC = SetBit(PORTC, 5, 0); //Set RCLK to low
	transmit_data(0x00);
	return state;
}

enum PatternFourStates_2 {Start_Four_2};
void PatternFour_2(int state)
{
	PORTC = SetBit(PORTC, 1, 0); //Set RCLK to low
	transmit_data(0x00);
	return state;
}


void pattern_decoder(int pattern)
{
	TimerOff();
	switch(pattern)
	{
		case 0:
			tasks[1].state = Start_One;
			tasks[1].TickFct = &PatternOne;
			tasks[0].pattern = 0x00;
			break;
		case 1:
			tasks[1].state = Start_Two;
			tasks[1].TickFct = &PatternTwo;
			tasks[0].pattern = 0x01;
			break;
		case 2:
			tasks[1].state = Start_Three;
			tasks[1].TickFct = &PatternThree;
			tasks[0].pattern = 0x02;
			break;
		case 3:
			tasks[1].state = Start_Four;
			tasks[1].TickFct = &PatternFour;
			tasks[0].pattern = 0x03;		
	}
	TimerOn();
	
}

void pattern_decoder_2(int pattern1)
{
	TimerOff();
	switch(pattern1)
	{
		case 0:
		tasks[3].state = Start_One_2;
		tasks[3].TickFct = &PatternOne_2;
		tasks[2].pattern = 0x00;
		break;
		case 1:
		tasks[3].state = Start_Two_2;
		tasks[3].TickFct = &PatternTwo_2;
		tasks[2].pattern = 0x01;
		break;
		case 2:
		tasks[3].state = Start_Three_2;
		tasks[3].TickFct = &PatternThree_2;
		tasks[2].pattern = 0x02;
		break;
		case 3:
		tasks[3].state = Start_Four_2;
		tasks[3].TickFct = &PatternFour_2;
		tasks[2].pattern = 0x03;
	}
	TimerOn();
	
}

int main(void)
{
	DDRC = 0xFF; PORTC = 0x00;
	DDRD = 0xFF; PORTD = 0x00;
	DDRB = 0x00; PORTB = 0xFF;

	PORTC = SetBit(PORTC, 3, 1); //Set SRCLR to high
	PORTC = SetBit(PORTC, 5, 0); //Set RCLK to low
	unsigned char old_data;
	tasks[0].elapsedTime = 0;
	tasks[0].period = 50;
	tasks[0].state = start;
	tasks[0].TickFct = &ButtonToggle;	
	tasks[0].pattern = 0x00;
	
	tasks[1].elapsedTime = 0;
	tasks[1].period = 200;
	tasks[1].pattern = 0;
	tasks[1].state = Start_One;
	tasks[1].TickFct = &PatternOne;
	
	tasks[2].elapsedTime = 0;
	tasks[2].period = 50;
	tasks[2].state = start_2;
	tasks[2].TickFct = &ButtonToggle2;
	tasks[2].pattern = 0x00;	
	
	tasks[3].elapsedTime = 0;
	tasks[3].period = 200;
	tasks[3].state = Start_One_2;
	tasks[3].TickFct = &PatternOne_2;
	tasks[3].pattern = 0x00;	
	
	TimerSet(PERIOD);
	TimerOn();
	while (1)
	{
		PORTD = patterns;
		if(tasks[0].pattern != patterns)
			{	
				pattern_decoder(patterns);
			} 
		if(tasks[2].pattern != patterns1)
		{
			pattern_decoder_2(patterns1);
		}
		continue;
		//Test

	}
	
}
