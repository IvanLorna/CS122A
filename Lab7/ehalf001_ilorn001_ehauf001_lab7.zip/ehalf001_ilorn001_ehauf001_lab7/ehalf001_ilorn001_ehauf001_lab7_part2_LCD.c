/*    Name & Email: Emanuel Halfon / ehalf001@ucr.edu
 *    Partner(s) Name & E-mail: Ivan Lorna / ilorn001@ucr.edu, Evan Hauff / ehauf001@ucr.edu
 *    Lab Section:  021
 *    Assignment: Lab 7 Part 2 LCD Display
 *    Exercise Description: [optional - include for your own benefit]
 *    
 *    I acknowledge all content contained herein, excluding template 
 *     or example code, is my own original work.
 */


#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include "io.c"
#include "SPI.h"
#include <stdio.h>


volatile unsigned char TimerFlag = 0; // TimerISR() sets this to 1. C programmer should clear to 0.
volatile unsigned char port_B = 0x00;
unsigned char on_off = 0x00;
// Internal variables for mapping AVR's ISR to our cleaner TimerISR model.
unsigned long _avr_timer_M = 1; // Start count from here, down to 0. Default 1 ms.
unsigned long _avr_timer_cntcurr = 0; // Current internal count of 1ms ticks
unsigned char data = 0x00;
const unsigned long PERIOD = 500;
unsigned short adc_val;

unsigned char SetBit(unsigned char pin, unsigned char number, unsigned char bin_value)
{
	return (bin_value ? pin | (0x01 << number) : pin & ~(0x01 << number));
}

unsigned char GetBit(unsigned char port, unsigned char number)
{
	return ( port & (0x01 << number) );
}

void ADC_init() 
{
	ADCSRA |= (1 << ADEN) | (1 << ADSC) | (1 << ADATE);
}

void enableInterrupts(void){
	SPCR |= (1<<SPIE);
	SPCR |= (1<<SPE);
	PCICR |= (1 << PCIE1);
	PCMSK1 |= (1 << PCINT13);
	PCMSK1 |= (1 << PCINT14);
}

void TimerOn() {
	// AVR timer/counter controller register TCCR1
	TCCR1B = 0x0B;
	// AVR output compare register OCR1A.
	OCR1A = 125;	// Timer interrupt will be generated when TCNT1==OCR1A
	TIMSK1 = 0x02; // bit1: OCIE1A -- enables compare match interrupt

	//Initialize avr counter
	TCNT1=0;

	_avr_timer_cntcurr = _avr_timer_M;
	SREG |= 0x80; // 0x80: 1000000 
}

void TimerOff() {
	TCCR1B = 0x00; // bit3bit1bit0=000: timer off
}


typedef struct Task {
	int state; // Task�s current state
	unsigned long period; // Task period
	unsigned long elapsedTime; // Time elapsed since last task tick
	unsigned char active;
	int (*TickFct)(int); // Task tick function
} task;


const unsigned char tasksSize = 1;
task tasks[1];




void TimerISR()
{
	unsigned char i;
	for (i = 0;i < tasksSize;++i)
	{
		if ((tasks[i].elapsedTime >= tasks[i].period) && tasks[i].active)
		{
			tasks[i].state = tasks[i].TickFct(tasks[i].state);
			tasks[i].elapsedTime = 0;
		}
		tasks[i].elapsedTime += PERIOD;
	}
}



ISR(TIMER1_COMPA_vect) {
	// CPU automatically calls when TCNT1 == OCR1 (every 1 ms per TimerOn settings)
	_avr_timer_cntcurr--; // Count down to 0 rather than up to TOP
	if (_avr_timer_cntcurr == 0) { // results in a more efficient compare
		TimerISR(); // Call the ISR that the user uses
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

// Set TimerISR() to tick every M ms
void TimerSet(unsigned long M) {
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}



enum States {start};
int Display(int state)
{
	unsigned char command = SPI_SlaveReceive();
		if(command == 0x40)
		{
			LCD_DisplayString(17, " Current");
		}
		else if (command = 0x20)
		{
			LCD_DisplayString(17, " Average");
		}
	data = SPI_SlaveReceive();
	unsigned char data_h = data / 100;
	unsigned char data_t = (data - (data_h*100)) / 10;
	unsigned char data_o = (data - (data_h*100) - (data_t*10));
	//unsigned char i = 0x01;
	LCD_Cursor(1);
	LCD_WriteData('0' + data_h);
	LCD_Cursor(2);
	LCD_WriteData('0' + data_t);
	LCD_Cursor(3);
	LCD_WriteData('0' + data_o);	

	return state;
}

enum ADC_States{start2};
int ADCSM(int state)
{
	adc_val = ADC;
	SPDR = adc_val;
	return state;
}

int main(void)
{
	DDRA = 0x00; PORTA = 0xFF;
	DDRB = 0xFF; PORTB = 0x00;
	DDRC = 0xFF; PORTC = 0x00;
	DDRD = 0xFF; PORTD = 0x00;	
	tasks[0].active = 1;
	tasks[0].elapsedTime = 0;
	tasks[0].period = 500;
	tasks[0].TickFct = &Display;
	tasks[0].state = start;
	SPI_SlaveInit();
	LCD_init();
	LCD_ClearScreen();
	//enableInterrupts();
	ADC_init();
	TimerSet(PERIOD);
	TimerOn();
	//sei();
	while(1)
	{
		//adc_val = ADC;
		//SPDR = adc_val;			
		continue;
	}
	return 0;
}




