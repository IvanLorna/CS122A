import spidev
import time
import math

_numValues = 0
_mean = 0
_s = 0


def WelfordsAlgorithm(newLightValue):
    global _numValues
    global _mean
    global _s
    _numValues += 1
    if _numValues == 1:
        _mean = newLightValue
        _s = 0
    else:
        _oldMean = _mean
        _mean =_oldMean + (int(newLightValue)-int(_oldMean)) / _numValues
        _s = _s + ((newLightValue - _oldMean) * (newLightValue - _mean))
    return _mean



def createSPI(device):
        if device is 0:
            spi0 = spidev.SpiDev()
            spi0.open(0,0)
            spi0.max_speed_hz= 1000000
            spi0.mode = 0
            return spi0
        else:
            spi1 = spidev.SpiDev()
            spi1.open(0,1)
            spi1.max_speed_hz = 1000000
            spi1.mode = 1
            return spi1


if __name__ == '__main__': 
        spi0 = createSPI(0)
        spi1 = createSPI(1)
        try:
            while True:
                resp = spi0.readbytes(1)
                #resp1 = spi0.xfer([0xFF])
                average = [WelfordsAlgorithm(resp[0])]
                print('average: ',average)
                print('current: ',resp)
                   # print('current: ',resp1)
                spi1.writebytes([math.floor(average[0])])
                time.sleep(1)
	    #end while
        except KeyboardInterrupt:
            spi0.close()
            spi1.close()
            exit()
        #endtry
